import { AwsApiInput } from '../aws-api';
export declare function handler(event: AwsApiInput): Promise<void>;
