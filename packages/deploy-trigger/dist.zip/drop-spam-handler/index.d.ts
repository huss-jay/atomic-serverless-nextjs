export declare function handler(event: AWSLambda.SESEvent): Promise<{
    disposition: string;
} | null>;
