import { Event } from '../evaluate-expression';
export declare function handler(event: Event): Promise<any>;
