export declare function handler(event: any, _context: any): Promise<void>;
