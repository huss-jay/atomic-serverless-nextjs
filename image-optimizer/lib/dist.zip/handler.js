"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
// Ensure NODE_ENV is set to production
process.env.NODE_ENV = 'production';
// Set NEXT_SHARP_PATH environment variable
// ! Make sure this comes before the fist import
process.env.NEXT_SHARP_PATH = require.resolve('sharp');
const url_1 = require("url");
const config_shared_1 = require("next/dist/server/config-shared");
const s3_1 = __importDefault(require("aws-sdk/clients/s3"));
const image_optimizer_1 = require("./image-optimizer");
const normalized_headers_1 = require("./normalized-headers");
/* -----------------------------------------------------------------------------
 * Utils
 * ---------------------------------------------------------------------------*/
function generateS3Config(bucketName) {
    let s3;
    if (!bucketName) {
        return undefined;
    }
    // Only for testing purposes when connecting against a local S3 backend
    if (process.env.__DEBUG__USE_LOCAL_BUCKET) {
        s3 = new s3_1.default(JSON.parse(process.env.__DEBUG__USE_LOCAL_BUCKET));
    }
    else {
        s3 = new s3_1.default();
    }
    return {
        s3,
        bucket: bucketName,
    };
}
function parseFromEnv(key, defaultValue) {
    try {
        const envValue = process.env[key];
        if (typeof envValue === 'string') {
            return JSON.parse(envValue);
        }
        return defaultValue;
    }
    catch (err) {
        console.error(`Could not parse ${key} from environment variable`);
        console.error(err);
        return defaultValue;
    }
}
/* -----------------------------------------------------------------------------
 * Globals
 * ---------------------------------------------------------------------------*/
// `images` property is defined on default config
// eslint-disable-next-line @typescript-eslint/no-non-null-assertion
const imageConfigDefault = config_shared_1.defaultConfig.images;
const domains = parseFromEnv('TF_NEXTIMAGE_DOMAINS', imageConfigDefault.domains ?? []);
const deviceSizes = parseFromEnv('TF_NEXTIMAGE_DEVICE_SIZES', imageConfigDefault.deviceSizes);
const formats = parseFromEnv('TF_NEXTIMAGE_FORMATS', imageConfigDefault.formats);
const imageSizes = parseFromEnv('TF_NEXTIMAGE_IMAGE_SIZES', imageConfigDefault.imageSizes);
const dangerouslyAllowSVG = parseFromEnv('TF_NEXTIMAGE_DANGEROUSLY_ALLOW_SVG', imageConfigDefault.dangerouslyAllowSVG);
const contentSecurityPolicy = parseFromEnv('TF_NEXTIMAGE_CONTENT_SECURITY_POLICY', imageConfigDefault.contentSecurityPolicy);
const sourceBucket = process.env.TF_NEXTIMAGE_SOURCE_BUCKET ?? undefined;
const baseOriginUrl = process.env.TF_NEXTIMAGE_BASE_ORIGIN ?? undefined;
const imageConfig = {
    ...imageConfigDefault,
    domains,
    deviceSizes,
    formats,
    imageSizes,
    dangerouslyAllowSVG,
    contentSecurityPolicy,
};
/* -----------------------------------------------------------------------------
 * Handler
 * ---------------------------------------------------------------------------*/
async function handler(event) {
    const s3Config = generateS3Config(sourceBucket);
    const parsedUrl = url_1.parse(`/?${event.rawQueryString}`, true);
    const imageOptimizerResult = await image_optimizer_1.imageOptimizer({ headers: normalized_headers_1.normalizeHeaders(event.headers) }, imageConfig, {
        baseOriginUrl,
        parsedUrl,
        s3Config,
    });
    if ('error' in imageOptimizerResult) {
        return {
            statusCode: imageOptimizerResult.statusCode,
            body: imageOptimizerResult.error,
        };
    }
    const { contentType, paramsResult, maxAge } = imageOptimizerResult;
    const { isStatic, minimumCacheTTL } = paramsResult;
    const cacheTTL = Math.max(minimumCacheTTL, maxAge);
    const normalizedHeaders = {
        Vary: 'Accept',
        'Content-Type': contentType,
        'Cache-Control': isStatic
            ? 'public, max-age=315360000, immutable'
            : `public, max-age=${cacheTTL}`,
    };
    if (imageConfig.contentSecurityPolicy) {
        normalizedHeaders['Content-Security-Policy'] =
            imageConfig.contentSecurityPolicy;
    }
    return {
        statusCode: 200,
        body: imageOptimizerResult.buffer.toString('base64'),
        isBase64Encoded: true,
        headers: normalizedHeaders,
    };
}
exports.handler = handler;
