"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeHeaders = void 0;
/**
 * Normalizes the headers from API Gateway 2.0 format
 */
function normalizeHeaders(headers) {
    const _headers = {};
    for (const [key, value] of Object.entries(headers)) {
        _headers[key.toLowerCase()] = value;
    }
    return _headers;
}
exports.normalizeHeaders = normalizeHeaders;
